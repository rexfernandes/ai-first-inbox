// config.js
// Fill these in with your own Supabase project's values.
// Project Settings → API → Project URL / anon public key.
// The anon key is safe to expose client-side — access is controlled by
// Row Level Security policies (see supabase-schema.sql), not by hiding this key.

const SUPABASE_URL = "https://YOUR-PROJECT-REF.supabase.co";
const SUPABASE_ANON_KEY = "YOUR-ANON-PUBLIC-KEY";
